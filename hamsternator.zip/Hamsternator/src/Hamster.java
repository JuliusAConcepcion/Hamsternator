import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.net.URL;

public class Hamster extends Character{
	
	public Hamster() {
		
		super("/pictures/HamsterMotorcyle (7).gif");
		
	}
	
	
	
	
}
